import React from "react";

const PostsContext = React.createContext();

export default PostsContext;